library(testthat)
library(patientAnalytics)  # Load your package

test_check("patientAnalytics")  # Run all tests inside tests/testthat/
